package dev.yum.pairingexercise.models

// TODO: create model/s needed for JSON coming from employees.json
// Use "@JsonClass(generateAdapter = true)" above class to generate moshi adapters
