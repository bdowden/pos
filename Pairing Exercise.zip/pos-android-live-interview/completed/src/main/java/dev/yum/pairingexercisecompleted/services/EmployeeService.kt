package dev.yum.pairingexercisecompleted.services

import dev.yum.pairingexercisecompleted.models.Employee
import kotlinx.coroutines.flow.Flow

interface EmployeeService {
    /**
     * Emits an a list of [Employee]s from the local employee file.
     */
    // TODO: define what getEmployees() returns
    // note: just have this as `fun getEmployees()`. this also allows to use Flow or LiveData
    fun getEmployees(): Flow<List<Employee>>
}
