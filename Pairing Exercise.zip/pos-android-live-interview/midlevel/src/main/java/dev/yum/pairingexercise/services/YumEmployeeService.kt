package dev.yum.pairingexercise.services

import android.content.Context
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class YumEmployeeService(private val context: Context) : EmployeeService {

    // TODO: replace the StubEmployeeResponse class with your EmployeeResponse model
    // TODO: update what getEmployees() returns
    // TODO: add (manual) dependency injection for moshi instance
    override fun getEmployees() {
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val reader = context.assets.open("employees.json").bufferedReader().use { it.readText() }
        val jsonAdapter: JsonAdapter<StubEmployeeResponse> = moshi.adapter(StubEmployeeResponse::class.java)
        val employeeResponse = jsonAdapter.fromJson(reader)
    }
}

private class StubEmployeeResponse
