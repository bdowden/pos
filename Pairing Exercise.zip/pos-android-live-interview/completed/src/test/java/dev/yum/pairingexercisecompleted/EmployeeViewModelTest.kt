package dev.yum.pairingexercisecompleted

import com.nhaarman.mockito_kotlin.whenever
import dev.yum.pairingexercisecompleted.models.Employee
import dev.yum.pairingexercisecompleted.services.EmployeeService
import dev.yum.pairingexercisecompleted.viewmodels.EmployeeViewModel
import io.reactivex.Observable
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.MockitoAnnotations

class EmployeeViewModelTest {

    @Mock
    private lateinit var employeesService: EmployeeService

    @Mock
    private lateinit var employee: Employee
    private lateinit var viewModel: EmployeeViewModel

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)

        whenever(employeesService.getEmployees()).thenReturn(Observable.just(listOf(employee, employee)))

        viewModel = EmployeeViewModel(employeesService)
    }

    @Test
    fun employees_hasValidData_returnsEmployeeResponse() {
        viewModel.getEmployees()
            .test()
            .assertValue(listOf(employee, employee))
    }
}
