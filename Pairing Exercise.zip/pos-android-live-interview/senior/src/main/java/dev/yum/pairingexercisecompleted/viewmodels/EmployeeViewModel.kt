package dev.yum.pairingexercisecompleted.viewmodels

import androidx.lifecycle.ViewModel
import dev.yum.pairingexercisecompleted.models.Employee
import dev.yum.pairingexercisecompleted.services.EmployeeService

class EmployeeViewModel(private val employeeService: EmployeeService) : ViewModel() {

    fun getEmployees() = employeeService.getEmployees()

    fun filterList(location: Employee.Location) {
    }
}
