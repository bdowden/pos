package dev.yum.pairingexercise.services

interface EmployeeService {
    /**
     * Emits an a list of [Employee]s from the local employee file.
     */
    // TODO: define what getEmployees() returns
    fun getEmployees()
}
