package dev.yum.pairingexercise.views

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import dev.yum.pairingexercise.databinding.ItemEmployeeBinding

//TODO: replace the StubEmployee class with your Employee model
//TODO: implement the areItemsTheSame() method based on your model
//TODO: implement the bind method to show the following:
/**
 * <name>
 * Title: <title>
 * Locations: <locations>
 */
class EmployeesAdapter : ListAdapter<StubEmployee, EmployeesAdapter.EmployeeViewHolder>(DIFF_UTIL) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmployeeViewHolder =
        EmployeeViewHolder(
            ItemEmployeeBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: EmployeeViewHolder, position: Int): Unit =
        holder.bind(getItem(position))

    inner class EmployeeViewHolder(private val binding: ItemEmployeeBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(employee: StubEmployee) {
            // TODO
        }
    }

    companion object {
        val DIFF_UTIL = object : DiffUtil.ItemCallback<StubEmployee>() {
            override fun areItemsTheSame(oldItem: StubEmployee, newItem: StubEmployee): Boolean =
                TODO()

            override fun areContentsTheSame(oldItem: StubEmployee, newItem: StubEmployee): Boolean =
                oldItem == newItem
        }
    }
}

class StubEmployee
