package dev.yum.pairingexercisecompleted.services

import android.content.Context
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import dev.yum.pairingexercisecompleted.models.Employee
import dev.yum.pairingexercisecompleted.models.EmployeeResponse
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

class YumEmployeeService(private val context: Context, private val moshi: Moshi) : EmployeeService {

    // TODO: replace the StubEmployee class with your Employee model
    // TODO: update what getEmployees() returns
    // TODO: add (manual) dependency injection for moshi instance
    // note: instantiate moshi instance here and rest of json adapter stuff,  don't think figuring out reading local json is what we want to test
    // note: would like them to do the subscribeOn here
    override fun getEmployees(): Flow<List<Employee>> {
        val reader = context.assets.open("employees.json").bufferedReader().use { it.readText() }
        val jsonAdapter: JsonAdapter<EmployeeResponse> = moshi.adapter(EmployeeResponse::class.java)
        val employees = jsonAdapter.fromJson(reader)?.employees ?: emptyList()
        return flowOf(employees)
    }
}
