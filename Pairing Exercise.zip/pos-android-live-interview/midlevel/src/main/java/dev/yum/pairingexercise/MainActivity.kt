package dev.yum.pairingexercise

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import dev.yum.pairingexercise.databinding.ActivityMainBinding

//TODO: create an accompanying ViewModel
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // TODO: set up and populate the employees recycler
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_filter, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // TODO: filter the employee list by the selected location
        when (item.itemId) {
            R.id.sort_austin -> TODO()
            R.id.sort_chicago -> TODO()
            R.id.sort_new_york -> TODO()
            R.id.sort_all -> TODO()
            else -> super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
    }
}
