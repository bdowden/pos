package dev.yum.pairingexercisecompleted.viewmodels

import androidx.lifecycle.ViewModel
import dev.yum.pairingexercisecompleted.models.Employee
import dev.yum.pairingexercisecompleted.services.EmployeeService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine

class EmployeeViewModel(private val employeeService: EmployeeService) : ViewModel() {

    private val filter = MutableStateFlow(Employee.Location.ALL)

    data class State(val filter: Employee.Location, val employees: List<Employee>)

    val state = combine(employeeService.getEmployees(), filter) { employees, filter ->
        val filteredEmployees = when (filter) {
            Employee.Location.ALL -> employees
            else -> employees.filter { it.locations.contains(filter) }
        }
        State(filter, filteredEmployees)
    }

    fun getEmployees() = combine(employeeService.getEmployees(), filter) { employees, filter ->
        when (filter) {
            Employee.Location.ALL -> employees
            else -> employees.filter { it.locations.contains(filter) }
        }
    }

    fun filterList(location: Employee.Location) {
        filter.value = location
    }
}
